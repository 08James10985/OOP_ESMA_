﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using ResortManagement_WindowsF.CLASS;


namespace ResortManagement_WindowsF
{
    public partial class ConferenceRoomfrm : Form
    {
        public ConferenceRoomfrm()
        {
            InitializeComponent();
        }

        private static readonly HttpClient client = new HttpClient();

        private async void button9_Click(object sender, EventArgs e)
        {
            string apiUrl = "http://localhost:5083/api/ConferenceRoom" +
                "";


            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseData = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to a list of ComboMeal objects
                List<ConferenceRoom> conferenceRooms = JsonConvert.DeserializeObject<List<ConferenceRoom>>(responseData);

                // Bind the data to the DataGridView
                dataGridView1.DataSource = conferenceRooms;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Request error: {ex.Message}");
            }

        }

        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ConferenceRoomfrm();
            form.Show();
        }

        private void cottageManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageManagementfrm();
            form.Show();
        }

        private void cottageReefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageReeffrm();
            form.Show();
        }

        private void comboMealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ComboMealfrm();
            form.Show();
        }

        private void trinaryHallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new TrinaryHallfrm();
            form.Show();
        }

        private async void btnPost_Click(object sender, EventArgs e)
        {
            // Ensure all required fields are filled
            if (string.IsNullOrWhiteSpace(txtID.Text) ||
                string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtCapacity.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Validate ID input
            if (!int.TryParse(txtID.Text, out int conferenceRoomId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the Conference Room ID already exists
            if (await ConferenceRoomIdExists(conferenceRoomId))
            {
                MessageBox.Show($"Conference Room with ID {conferenceRoomId} already exists.");
                return;
            }

            // Gather data from inputs
            ConferenceRoom newConferenceRoom = new ConferenceRoom
            {
                Id = conferenceRoomId,
                Name = txtName.Text,
                Capacity = int.Parse(txtCapacity.Text),
                IsAvailable = chkIsAvailable.Checked,
                CateringServices = chkCateringServices.Checked,
                HasTechnicalSupport = chkHasTechnicalSupport.Checked
            };

            // API URL for adding a new Conference Room
            string apiUrl = "http://localhost:5083/api/ConferenceRoom";

            try
            {
                string jsonData = JsonConvert.SerializeObject(newConferenceRoom);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(apiUrl, content);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("Conference Room added successfully!");

                // Optionally, clear the fields after adding
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        // Method to check if a Conference Room ID already exists
        private async Task<bool> ConferenceRoomIdExists(int id)
        {
            string apiUrl = $"http://localhost:5083/api/ConferenceRoom/{id}";
            HttpResponseMessage response = await client.GetAsync(apiUrl);
            return response.IsSuccessStatusCode; // Returns true if the ID exists
        }

        // Method to clear the input fields
        private void ClearFields()
        {
            txtID.Clear();
            txtName.Clear();
            txtCapacity.Clear();
            chkIsAvailable.Checked = false;
            chkCateringServices.Checked = false;
            chkHasTechnicalSupport.Checked = false;
        }

        private async void btnPut_Click(object sender, EventArgs e)
        {
            // Ensure all required fields are filled
            if (string.IsNullOrWhiteSpace(txtID.Text) ||
                string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtCapacity.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Validate ID input
            if (!int.TryParse(txtID.Text, out int conferenceRoomId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the Conference Room ID exists before updating
            if (!await ConferenceRoomIdExists(conferenceRoomId))
            {
                MessageBox.Show($"Conference Room with ID {conferenceRoomId} does not exist.");
                return;
            }

            // Gather data from inputs to create an updated ConferenceRoom object
            ConferenceRoom updatedConferenceRoom = new ConferenceRoom
            {
                Id = conferenceRoomId,
                Name = txtName.Text,
                Capacity = int.Parse(txtCapacity.Text),
                IsAvailable = chkIsAvailable.Checked,
                CateringServices = chkCateringServices.Checked,
                HasTechnicalSupport = chkHasTechnicalSupport.Checked
            };

            // API URL for updating the Conference Room with the specified ID
            string apiUrl = $"http://localhost:5083/api/ConferenceRoom/{conferenceRoomId}";

            try
            {
                string jsonData = JsonConvert.SerializeObject(updatedConferenceRoom);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync(apiUrl, content);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("Conference Room updated successfully!");

                // Optionally, clear the fields after editing
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter the ID of the Conference Room to delete.");
                return;
            }

            // Validate ID input
            if (!int.TryParse(txtID.Text, out int conferenceRoomId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the Conference Room ID exists before deleting
            if (!await DoesConferenceRoomIdExist(conferenceRoomId))
            {
                MessageBox.Show($"Conference Room with ID {conferenceRoomId} does not exist.");
                return;
            }

            // API URL for deleting the Conference Room with the specified ID
            string apiUrl = $"http://localhost:5083/api/ConferenceRoom/{conferenceRoomId}";

            try
            {
                HttpResponseMessage response = await client.DeleteAsync(apiUrl);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("Conference Room deleted successfully!");

                // Optionally, clear the fields after deleting
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private async Task<bool> DoesConferenceRoomIdExist(int id)
        {
            string apiUrl = $"http://localhost:5083/api/ConferenceRoom/{id}";
            HttpResponseMessage response = await client.GetAsync(apiUrl);

            // If the status code is 200 (OK), the ID exists
            return response.IsSuccessStatusCode;
        }


        private async void btnSearchID_Click(object sender, EventArgs e)
        {
            string searchIdInput = txtSearchID.Text;
            if (string.IsNullOrWhiteSpace(searchIdInput))
            {
                MessageBox.Show("Please enter the ID of the Conference Room to search.");
                return;
            }

            // Validate ID input
            if (!int.TryParse(searchIdInput, out int conferenceRoomId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // API URL for getting the Conference Room with the specified ID
            string apiUrl = $"http://localhost:5083/api/ConferenceRoom/{conferenceRoomId}";

            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    ConferenceRoom conferenceRoom = JsonConvert.DeserializeObject<ConferenceRoom>(jsonResponse);

                    // Populate fields with the retrieved conference room data
                    txtName.Text = conferenceRoom.Name;
                    txtCapacity.Text = conferenceRoom.Capacity.ToString();
                    chkIsAvailable.Checked = conferenceRoom.IsAvailable;
                    chkCateringServices.Checked = conferenceRoom.CateringServices;
                    chkHasTechnicalSupport.Checked = conferenceRoom.HasTechnicalSupport;
                    txtID.Text = conferenceRoom.Id.ToString();
                }
                else
                {
                    MessageBox.Show($"Conference Room with ID {conferenceRoomId} not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
    }
}
