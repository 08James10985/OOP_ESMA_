﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net.Http;
using Newtonsoft.Json;
using ResortManagement_WindowsF.CLASS;


namespace ResortManagement_WindowsF
{
    public partial class TrinaryHallfrm : Form
    {
        public TrinaryHallfrm()
        {
            InitializeComponent();
        }
        private static readonly HttpClient client = new HttpClient();
        private void TrinaryHallfrm_Load(object sender, EventArgs e)
        {

        }

        private async void button9_Click(object sender, EventArgs e)
        {
            string apiUrl = "http://localhost:5083/api/TrinaryHall";


            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseData = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to a list of ComboMeal objects
                List<TrinaryHall> trinaryHalls = JsonConvert.DeserializeObject<List<TrinaryHall>>(responseData);

                // Bind the data to the DataGridView
                dataGridView1.DataSource = trinaryHalls;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Request error: {ex.Message}");
            }
        }

        private async void btnPost_Click(object sender, EventArgs e)
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall ID.");
                return;
            }

            if (!int.TryParse(txtID.Text, out int trinaryHallId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtHallName.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall Name.");
                return;
            }

            if (!int.TryParse(txtCapacity.Text, out int capacity))
            {
                MessageBox.Show("Invalid capacity format. Please enter a valid number.");
                return;
            }

            if (!decimal.TryParse(txtRentalPrice.Text, out decimal rentalPrice))
            {
                MessageBox.Show("Invalid rental price format. Please enter a valid decimal number.");
                return;
            }

            // API URL to check if the ID exists
            string apiUrlCheck = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

            try
            {
                // Check if Trinary Hall ID already exists
                HttpResponseMessage checkResponse = await client.GetAsync(apiUrlCheck);

                if (checkResponse.IsSuccessStatusCode)
                {
                    // ID exists, display a message and return
                    MessageBox.Show($"Trinary Hall with ID {trinaryHallId} already exists.");
                    return;
                }
                else if (checkResponse.StatusCode != System.Net.HttpStatusCode.NotFound)
                {
                    // Handle unexpected errors (not 404 for not found)
                    MessageBox.Show("Error checking existing Trinary Hall ID.");
                    return;
                }

                // Gather data from inputs
                TrinaryHall newTrinaryHall = new TrinaryHall
                {
                    Id = trinaryHallId,
                    HallName = txtHallName.Text,
                    IsAvailable = chkIsAvailable.Checked,
                    Capacity = capacity,
                    RentalPricePerHour = rentalPrice
                };

                // API URL for adding a new Trinary Hall
                string apiUrlAdd = "http://localhost:5083/api/TrinaryHall";

                // Serialize the new Trinary Hall object to JSON
                string jsonData = JsonConvert.SerializeObject(newTrinaryHall);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the POST request to the API
                HttpResponseMessage addResponse = await client.PostAsync(apiUrlAdd, content);
                addResponse.EnsureSuccessStatusCode();

                MessageBox.Show("Trinary Hall added successfully!");

                // Optionally, clear the fields after adding
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
        private void ClearFields()
        {
            txtID.Text = string.Empty;
            txtSearchID.Text = string.Empty;
            txtRentalPrice.Text = string.Empty;
            txtHallName.Text = string.Empty;
            txtCapacity.Text = string.Empty;
            chkIsAvailable.Checked = false;
           
        }

        private async void btnPut_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall ID to update.");
                return;
            }

            if (!int.TryParse(txtID.Text, out int trinaryHallId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtHallName.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall Name.");
                return;
            }

            if (!int.TryParse(txtCapacity.Text, out int capacity))
            {
                MessageBox.Show("Invalid capacity format. Please enter a valid number.");
                return;
            }

            if (!decimal.TryParse(txtRentalPrice.Text, out decimal rentalPrice))
            {
                MessageBox.Show("Invalid rental price format. Please enter a valid decimal number.");
                return;
            }

            // API URL to check if the ID exists
            string apiUrlCheck = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

            try
            {
                // Check if Trinary Hall ID exists
                HttpResponseMessage checkResponse = await client.GetAsync(apiUrlCheck);

                if (checkResponse.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    // ID does not exist, display a message and return
                    MessageBox.Show($"Trinary Hall with ID {trinaryHallId} does not exist.");
                    return;
                }
                else if (!checkResponse.IsSuccessStatusCode)
                {
                    // Handle unexpected errors (not 200 OK or 404 Not Found)
                    MessageBox.Show("Error checking existing Trinary Hall ID.");
                    return;
                }

                // Gather data from inputs
                TrinaryHall updatedTrinaryHall = new TrinaryHall
                {
                    Id = trinaryHallId,
                    HallName = txtHallName.Text,
                    IsAvailable = chkIsAvailable.Checked,
                    Capacity = capacity,
                    RentalPricePerHour = rentalPrice
                };

                // API URL for updating the Trinary Hall
                string apiUrlUpdate = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

                // Serialize the updated Trinary Hall object to JSON
                string jsonData = JsonConvert.SerializeObject(updatedTrinaryHall);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the PUT request to the API
                HttpResponseMessage updateResponse = await client.PutAsync(apiUrlUpdate, content);
                updateResponse.EnsureSuccessStatusCode();

                MessageBox.Show("Trinary Hall updated successfully!");

                // Optionally, clear the fields after updating
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall ID to delete.");
                return;
            }

            if (!int.TryParse(txtID.Text, out int trinaryHallId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // API URL to check if the ID exists
            string apiUrlCheck = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

            try
            {
                // Check if the Trinary Hall ID exists
                HttpResponseMessage checkResponse = await client.GetAsync(apiUrlCheck);

                if (checkResponse.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    MessageBox.Show($"Trinary Hall with ID {trinaryHallId} does not exist.");
                    return;
                }
                else if (!checkResponse.IsSuccessStatusCode)
                {
                    MessageBox.Show("Error checking existing Trinary Hall ID.");
                    return;
                }

                // Confirm deletion
                var confirmResult = MessageBox.Show("Are you sure you want to delete this Trinary Hall?",
                                                    "Confirm Delete",
                                                    MessageBoxButtons.YesNo);
                if (confirmResult != DialogResult.Yes)
                {
                    return; // Exit if the user does not confirm
                }

                // API URL for deletion
                string apiUrlDelete = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

                // Send the DELETE request to the API
                HttpResponseMessage deleteResponse = await client.DeleteAsync(apiUrlDelete);

                if (deleteResponse.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    MessageBox.Show("Trinary Hall not found.");
                    return;
                }

                deleteResponse.EnsureSuccessStatusCode();

                MessageBox.Show("Trinary Hall deleted successfully!");

                // Optionally, clear the fields after deletion
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }

        private async void btnSearchID_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearchID.Text))
            {
                MessageBox.Show("Please enter a Trinary Hall ID to search.");
                return;
            }

            if (!int.TryParse(txtSearchID.Text, out int trinaryHallId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // API URL to get the Trinary Hall by ID
            string apiUrl = $"http://localhost:5083/api/TrinaryHall/{trinaryHallId}";

            try
            {
                // Send the GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    MessageBox.Show("Trinary Hall not found.");
                    return;
                }

                response.EnsureSuccessStatusCode();

                // Read the JSON response and deserialize it into a TrinaryHall object
                string jsonResponse = await response.Content.ReadAsStringAsync();
                TrinaryHall foundTrinaryHall = JsonConvert.DeserializeObject<TrinaryHall>(jsonResponse);

                // Fill the form fields with the retrieved data
                txtID.Text = foundTrinaryHall.Id.ToString();
                txtHallName.Text = foundTrinaryHall.HallName;
                txtCapacity.Text = foundTrinaryHall.Capacity.ToString();
                chkIsAvailable.Checked = foundTrinaryHall.IsAvailable;
                txtRentalPrice.Text = foundTrinaryHall.RentalPricePerHour.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void cottageManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageManagementfrm();
            form.Show();
        }

        private void cottageReefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageReeffrm();
            form.Show();
        }

        private void comboMealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ComboMealfrm();
            form.Show();
        }

        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ConferenceRoomfrm();
            form.Show();
        }
    }
}
