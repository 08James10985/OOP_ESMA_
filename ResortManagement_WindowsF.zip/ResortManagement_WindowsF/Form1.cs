﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResortManagement_WindowsF
{
    public partial class Form1 : Form
    {
        bool sidebarExpand;
        public Form1()
        {
            InitializeComponent();
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                sidebar.Width -= 10;
                if (sidebar.Width <= sidebar.MinimumSize.Width) // Check if the width is less than or equal
                {
                    sidebar.Width = sidebar.MinimumSize.Width; // Ensure it doesn't go below minimum
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width >= sidebar.MaximumSize.Width) // Check if the width is greater than or equal
                {
                    sidebar.Width = sidebar.MaximumSize.Width; // Ensure it doesn't exceed maximum
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void loadform(object Form)
        {
            if (this.mainpanel.Controls.Count > 0)
                this.mainpanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainpanel.Controls.Add(f);
            this.mainpanel.Tag = f;
            f.Show();
        }




        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void trinaryHallToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void pbxMenu_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }

        private void lblmenu_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            loadform(new CottageManagementfrm());
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            loadform(new CottageManagementfrm());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            loadform(new ComboMealfrm());
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            loadform(new ComboMealfrm());
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            loadform(new CottageReeffrm());
           
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            loadform(new CottageReeffrm());
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            loadform(new TrinaryHallfrm());
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            loadform(new TrinaryHallfrm());
        }

        private void button6_Click(object sender, EventArgs e)
        {

            loadform(new ConferenceRoomfrm());
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            loadform(new ConferenceRoomfrm());
        }
    }
}
