﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResortManagement_WindowsF.CLASS
{
    public class TrinaryHall
    {
        public int Id { get; set; }
        public string HallName { get; set; }
        public int Capacity { get; set; }
        public bool IsAvailable { get; set; }
        public decimal RentalPricePerHour { get; set; }
    }
}
