﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResortManagement_WindowsF.CLASS
{
    public class MyClass
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsAvailable { get; set; }
        public int Capacity { get; set; }
        public DateTime CheckIn { get; set; }
        public DateTime CheckOut { get; set; }

        // Default constructor
        public MyClass() { }

        // Parameterized constructor
        public MyClass(int id, string name, bool isAvailable, int capacity, DateTime checkIn, DateTime checkOut)
        {
            Id = id;
            Name = name;
            IsAvailable = isAvailable;
            Capacity = capacity;
            CheckIn = checkIn;
            CheckOut = checkOut;
        }
    }
}
