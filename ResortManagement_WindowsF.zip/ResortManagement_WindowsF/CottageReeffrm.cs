﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;





using System.Net.Http;
using Newtonsoft.Json;
using ResortManagement_WindowsF.CLASS;



namespace ResortManagement_WindowsF
{
    public partial class CottageReeffrm : Form
    {
        public CottageReeffrm()
        {
            InitializeComponent();
        }









        private static readonly HttpClient client = new HttpClient();


        private async void button9_Click(object sender, EventArgs e)
        {
            string apiUrl = "http://localhost:5083/api/CottageReef";


            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseData = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to a list of ComboMeal objects
                List<CottageReef> comboMeals = JsonConvert.DeserializeObject<List<CottageReef>>(responseData);

                // Bind the data to the DataGridView
                dataGridView1.DataSource = comboMeals;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Request error: {ex.Message}");
            }
        }














        private void cottageManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageManagementfrm();
            form.Show();
        }

        private void trinaryHallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new TrinaryHallfrm();
            form.Show();
        }

        private void cottageReefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageReeffrm();
            form.Show();
        }

        private void comboMealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ComboMealfrm();
            form.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pbxHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new Form1();
            form.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CottageReeffrm_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSearchID_TextChanged(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtSearchID.Text, out int cottageReefId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // API URL to fetch the CottageReef by ID
            string apiUrl = $"http://localhost:5083/api/CottageReef/{cottageReefId}";

            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Check if the response indicates success
                if (response.IsSuccessStatusCode)
                {
                    // Deserialize the response data into a CottageReef object
                    string jsonData = await response.Content.ReadAsStringAsync();
                    CottageReef cottageReef = JsonConvert.DeserializeObject<CottageReef>(jsonData);

                    // Populate the fields with the retrieved data
                    txtActivityName.Text = cottageReef.ActivityName;
                    txtEquipRentPrice.Text = cottageReef.EquipmentRentalPrice.ToString("F2"); // Format to 2 decimal places
                    chkIsAvailable.Checked = cottageReef.IsAvailable;
                    txtSchedule.Text = cottageReef.Schedule;
                    // txtCottageID = cottageReef.Id;
                    txtCottageID.Text = cottageReef.Id.ToString();
                }
                else
                {
                    MessageBox.Show($"CottageReef with ID {cottageReefId} not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private async void btnPost_Click(object sender, EventArgs e)
        {
            // Get the CottageReef ID from the input
            string cottageIdInput = txtCottageID.Text; // Assuming you have a textbox for CottageReef ID
            if (string.IsNullOrWhiteSpace(cottageIdInput))
            {
                MessageBox.Show("Please enter a CottageReef ID.");
                return;
            }

            if (!int.TryParse(cottageIdInput, out int cottageReefId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the CottageReef ID already exists
            if (await CottageReefIdExists(cottageReefId))
            {
                MessageBox.Show($"CottageReef with ID {cottageReefId} already exists. Please use a different ID.");
                return;
            }

            // Gather data from inputs
            CottageReef newCottageReef = new CottageReef
            {
                Id = cottageReefId, // Set the ID here
                ActivityName = txtActivityName.Text,
                Description = txtDescription.Text, // New field for description
                IsAvailable = chkIsAvailable.Checked,
                EquipmentRentalPrice = decimal.Parse(txtEquipRentPrice.Text),
                Schedule = txtSchedule.Text
            };

            // API URL
            string apiUrl = "http://localhost:5083/api/CottageReef";

            try
            {
                string jsonData = JsonConvert.SerializeObject(newCottageReef);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    // Read the response content to get the error message
                    string errorContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Error: {response.StatusCode} - {errorContent}");
                    return;
                }

                MessageBox.Show("CottageReef created successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }


        }


        private async void btnPut_Click(object sender, EventArgs e)
        {
            // Get the CottageReef ID from the search box
            string searchIdInput = txtSearchID.Text;
            if (string.IsNullOrWhiteSpace(searchIdInput))
            {
                MessageBox.Show("Please enter a CottageReef ID to update.");
                return;
            }

            if (!int.TryParse(searchIdInput, out int cottageReefId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the CottageReef ID exists
            if (!await CottageReefIdExists(cottageReefId))
            {
                MessageBox.Show($"CottageReef with ID {cottageReefId} does not exist.");
                return;
            }

            // Gather data from inputs
            CottageReef updatedCottageReef = new CottageReef
            {
                Id = cottageReefId,
                ActivityName = txtActivityName.Text,
                Description = txtDescription.Text, // New field for description
                IsAvailable = chkIsAvailable.Checked,
                EquipmentRentalPrice = decimal.Parse(txtEquipRentPrice.Text),
                Schedule = txtSchedule.Text
            };

            // API URL
            string apiUrl = $"http://localhost:5083/api/CottageReef/{cottageReefId}";

            try
            {
                string jsonData = JsonConvert.SerializeObject(updatedCottageReef);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync(apiUrl, content);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("CottageReef updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            // Get the CottageReef ID from the search box
            string searchIdInput = txtSearchID.Text;
            if (string.IsNullOrWhiteSpace(searchIdInput))
            {
                MessageBox.Show("Please enter a CottageReef ID to delete.");
                return;
            }

            if (!int.TryParse(searchIdInput, out int cottageReefId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the CottageReef ID exists
            if (!await CottageReefIdExists(cottageReefId))
            {
                MessageBox.Show($"CottageReef with ID {cottageReefId} does not exist.");
                return;
            }

            // API URL
            string apiUrl = $"http://localhost:5083/api/CottageReef/{cottageReefId}";

            try
            {
                HttpResponseMessage response = await client.DeleteAsync(apiUrl);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("CottageReef deleted successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
        private async Task<bool> CottageReefIdExists(int cottageReefId)
        {
            string apiUrl = $"http://localhost:5083/api/CottageReef/{cottageReefId}"; // Adjust the URL as per your API
            HttpResponseMessage response = await client.GetAsync(apiUrl);

            return response.IsSuccessStatusCode; // Returns true if the CottageReef exists
        }

        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ConferenceRoomfrm();
            form.Show();
        }
    }
}
