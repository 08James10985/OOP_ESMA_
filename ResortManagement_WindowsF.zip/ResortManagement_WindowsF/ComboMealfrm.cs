﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ResortManagement_WindowsF.CLASS;

using System.Net.Http;
using Newtonsoft.Json;
using Microsoft.VisualBasic;
using System.Xml.Linq;
namespace ResortManagement_WindowsF
{
    public partial class ComboMealfrm : Form
    {

        private static readonly HttpClient client = new HttpClient();

        public ComboMealfrm()
        {
            InitializeComponent();
        }

       
        private async void button9_Click(object sender, EventArgs e)
        {

            string apiUrl = "http://localhost:5083/api/ComboMeal";


            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseData = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to a list of ComboMeal objects
                List<ComboMeal> comboMeals = JsonConvert.DeserializeObject<List<ComboMeal>>(responseData);

                // Bind the data to the DataGridView
                dataGridView1.DataSource = comboMeals;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Request error: {ex.Message}");
            }
        }






        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void cottageReefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageReeffrm();
            form.Show();
        }

        private void cottageManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageManagementfrm();
            form.Show();
        }

        private void comboMealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ComboMealfrm();
            form.Show();
        }

        private void trinaryHallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new TrinaryHallfrm();
            form.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pbxHome_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form form = new Form1();
            form.Show();
        }

        private void ComboMealfrm_Load(object sender, EventArgs e)
        {

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private async void button8_Click(object sender, EventArgs e)
        {
            string apiUrl = "http://localhost:5083/api/ComboMeal";

            // Ensure the ID is provided
            if (!int.TryParse(txtId.Text, out int comboMealId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the ComboMeal ID already exists
            if (await ComboMealIdExists(comboMealId))
            {
                MessageBox.Show($"ComboMeal with ID {comboMealId} already exists. Please use a different ID.");
                return;
            }

            // Create a new ComboMeal object with data from the form inputs
            ComboMeal newComboMeal = new ComboMeal
            {
                Id = comboMealId,
                MealName = txtMealName.Text,
                Price = decimal.Parse(txtPrice.Text),
                Description = txtDescription.Text
            };

            try
            {
                // Serialize the ComboMeal object to JSON
                string jsonData = JsonConvert.SerializeObject(newComboMeal);

                // Set up the HTTP content with JSON data and appropriate headers
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send a POST request to the API
                HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Notify the user that the post was successful
                MessageBox.Show("ComboMeal added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnPut_Click(object sender, EventArgs e)
        {
            // Ensure the ID is provided
            if (!int.TryParse(txtId.Text, out int comboMealId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the ComboMeal ID exists
            if (!await ComboMealIdExists(comboMealId))
            {
                MessageBox.Show($"ComboMeal with ID {comboMealId} does not exist. Cannot update.");
                return;
            }

            // Get new details from the TextBoxes
            string mealName = txtMealName.Text;
            string priceInput = txtPrice.Text;
            string description = txtDescription.Text;

            if (!decimal.TryParse(priceInput, out decimal price))
            {
                MessageBox.Show("Invalid Price format. Please enter a valid decimal number.");
                return;
            }

            // Create the updated ComboMeal object
            ComboMeal updatedComboMeal = new ComboMeal
            {
                Id = comboMealId,
                MealName = mealName,
                Price = price,
                Description = description
            };

            string apiUrl = $"http://localhost:5083/api/ComboMeal/{comboMealId}";

            try
            {
                // Serialize the ComboMeal object to JSON
                string jsonData = JsonConvert.SerializeObject(updatedComboMeal);

                // Set up the HTTP content with JSON data
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send a PUT request to the API
                HttpResponseMessage response = await client.PutAsync(apiUrl, content);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Notify the user of success
                MessageBox.Show("ComboMeal updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            // Ensure the ID is provided
            if (!int.TryParse(txtId.Text, out int comboMealId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the ComboMeal ID exists before trying to delete
            if (!await ComboMealIdExists(comboMealId))
            {
                MessageBox.Show($"ComboMeal with ID {comboMealId} does not exist. Cannot delete.");
                return;
            }

            string apiUrl = $"http://localhost:5083/api/ComboMeal/{comboMealId}";

            try
            {
                // Send a DELETE request to the API
                HttpResponseMessage response = await client.DeleteAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Notify the user of success
                MessageBox.Show("ComboMeal deleted successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private async Task<bool> ComboMealIdExists(int id)
        {
            string apiUrl = $"http://localhost:5083/api/ComboMeal/{id}";

            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ConferenceRoomfrm();
            form.Show();

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            // Ensure the ID is provided
            if (!int.TryParse(txtSearchID.Text, out int comboMealId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the ComboMeal ID exists before trying to search
            if (!await ComboMealIdExists(comboMealId))
            {
                MessageBox.Show($"ComboMeal with ID {comboMealId} does not exist.");
                return;
            }

            // API URL for getting the ComboMeal with the specified ID
            string apiUrl = $"http://localhost:5083/api/ComboMeal/{comboMealId}";

            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    ComboMeal comboMeal = JsonConvert.DeserializeObject<ComboMeal>(jsonResponse);

                    // Populate the fields with the retrieved ComboMeal data
                    txtMealName.Text = comboMeal.MealName; // Assuming you have a txtMealName TextBox for ComboMeal name
                    txtPrice.Text = comboMeal.Price.ToString(); // Assuming you have a txtPrice TextBox for ComboMeal price
                    txtDescription.Text = comboMeal.Description; // Assuming you have a txtDescription TextBox for ComboMeal description
                    txtId.Text = comboMeal.Id.ToString(); // Show the ComboMeal ID

                }
                else
                {
                    MessageBox.Show($"ComboMeal with ID {comboMealId} not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
      
    }


}
