﻿namespace ResortManagement_WindowsF
{
    partial class ConferenceRoomfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button9 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkHasTechnicalSupport = new System.Windows.Forms.CheckBox();
            this.chkCateringServices = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCapacity = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearchID = new System.Windows.Forms.Button();
            this.btnPut = new System.Windows.Forms.Button();
            this.txtSearchID = new System.Windows.Forms.TextBox();
            this.chkIsAvailable = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnPost = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Capacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsAvailable = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CateringServices = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.HasTechnicalSupport = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isAvailableDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cateringServicesDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.hasTechnicalSupportDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.conferenceRoomBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.conferenceRoomBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trinaryHallBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cottageReefBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conferenceRoomBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conferenceRoomBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trinaryHallBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cottageReefBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(332, 330);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(99, 36);
            this.button9.TabIndex = 54;
            this.button9.Text = "GET";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chkHasTechnicalSupport);
            this.panel2.Controls.Add(this.chkCateringServices);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtCapacity);
            this.panel2.Controls.Add(this.txtID);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnSearchID);
            this.panel2.Controls.Add(this.btnPut);
            this.panel2.Controls.Add(this.txtSearchID);
            this.panel2.Controls.Add(this.chkIsAvailable);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtName);
            this.panel2.Controls.Add(this.btnPost);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(307, 474);
            this.panel2.TabIndex = 57;
            // 
            // chkHasTechnicalSupport
            // 
            this.chkHasTechnicalSupport.AutoSize = true;
            this.chkHasTechnicalSupport.Location = new System.Drawing.Point(105, 211);
            this.chkHasTechnicalSupport.Name = "chkHasTechnicalSupport";
            this.chkHasTechnicalSupport.Size = new System.Drawing.Size(135, 17);
            this.chkHasTechnicalSupport.TabIndex = 54;
            this.chkHasTechnicalSupport.Text = "Has Technical Support";
            this.chkHasTechnicalSupport.UseVisualStyleBackColor = true;
            // 
            // chkCateringServices
            // 
            this.chkCateringServices.AutoSize = true;
            this.chkCateringServices.Location = new System.Drawing.Point(106, 188);
            this.chkCateringServices.Name = "chkCateringServices";
            this.chkCateringServices.Size = new System.Drawing.Size(104, 17);
            this.chkCateringServices.TabIndex = 53;
            this.chkCateringServices.Text = "Catering Service";
            this.chkCateringServices.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 51;
            this.label1.Text = "Capacity";
            // 
            // txtCapacity
            // 
            this.txtCapacity.Location = new System.Drawing.Point(64, 130);
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.Size = new System.Drawing.Size(213, 20);
            this.txtCapacity.TabIndex = 52;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(47, 75);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(229, 20);
            this.txtID.TabIndex = 49;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 48;
            this.label6.Text = "ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 42;
            this.label5.Text = "Search ID";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.Font = new System.Drawing.Font("Century", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(57, 279);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(84, 27);
            this.btnDelete.TabIndex = 47;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearchID
            // 
            this.btnSearchID.BackColor = System.Drawing.Color.White;
            this.btnSearchID.Font = new System.Drawing.Font("Century", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchID.ForeColor = System.Drawing.Color.Black;
            this.btnSearchID.Location = new System.Drawing.Point(203, 22);
            this.btnSearchID.Name = "btnSearchID";
            this.btnSearchID.Size = new System.Drawing.Size(73, 27);
            this.btnSearchID.TabIndex = 41;
            this.btnSearchID.Text = "Search";
            this.btnSearchID.UseVisualStyleBackColor = false;
            this.btnSearchID.Click += new System.EventHandler(this.btnSearchID_Click);
            // 
            // btnPut
            // 
            this.btnPut.BackColor = System.Drawing.Color.White;
            this.btnPut.Font = new System.Drawing.Font("Century", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPut.ForeColor = System.Drawing.Color.Black;
            this.btnPut.Location = new System.Drawing.Point(147, 279);
            this.btnPut.Name = "btnPut";
            this.btnPut.Size = new System.Drawing.Size(53, 27);
            this.btnPut.TabIndex = 46;
            this.btnPut.Text = "PUT";
            this.btnPut.UseVisualStyleBackColor = false;
            this.btnPut.Click += new System.EventHandler(this.btnPut_Click);
            // 
            // txtSearchID
            // 
            this.txtSearchID.Location = new System.Drawing.Point(104, 26);
            this.txtSearchID.Name = "txtSearchID";
            this.txtSearchID.Size = new System.Drawing.Size(93, 20);
            this.txtSearchID.TabIndex = 40;
            // 
            // chkIsAvailable
            // 
            this.chkIsAvailable.AutoSize = true;
            this.chkIsAvailable.Location = new System.Drawing.Point(106, 165);
            this.chkIsAvailable.Name = "chkIsAvailable";
            this.chkIsAvailable.Size = new System.Drawing.Size(80, 17);
            this.chkIsAvailable.TabIndex = 39;
            this.chkIsAvailable.Text = "Is Available";
            this.chkIsAvailable.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Conference Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(103, 104);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(173, 20);
            this.txtName.TabIndex = 33;
            // 
            // btnPost
            // 
            this.btnPost.BackColor = System.Drawing.Color.White;
            this.btnPost.Font = new System.Drawing.Font("Century", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPost.ForeColor = System.Drawing.Color.Black;
            this.btnPost.Location = new System.Drawing.Point(203, 279);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(73, 27);
            this.btnPost.TabIndex = 31;
            this.btnPost.Text = "POST";
            this.btnPost.UseVisualStyleBackColor = false;
            this.btnPost.Click += new System.EventHandler(this.btnPost_Click);
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.Location = new System.Drawing.Point(453, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(262, 36);
            this.button10.TabIndex = 52;
            this.button10.Text = "Conference Room";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.button10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1110, 41);
            this.panel1.TabIndex = 53;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Name,
            this.Capacity,
            this.IsAvailable,
            this.CateringServices,
            this.HasTechnicalSupport,
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.isAvailableDataGridViewCheckBoxColumn,
            this.cateringServicesDataGridViewCheckBoxColumn,
            this.hasTechnicalSupportDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.conferenceRoomBindingSource1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(307, 41);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(803, 273);
            this.dataGridView1.TabIndex = 56;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Id";
            this.Column1.HeaderText = "Id";
            this.Column1.Name = "Column1";
            this.Column1.Width = 50;
            // 
            // Name
            // 
            this.Name.DataPropertyName = "Name";
            this.Name.HeaderText = "Name";
            this.Name.Name = "Name";
            // 
            // Capacity
            // 
            this.Capacity.DataPropertyName = "Capacity";
            this.Capacity.HeaderText = "Capacity";
            this.Capacity.Name = "Capacity";
            // 
            // IsAvailable
            // 
            this.IsAvailable.DataPropertyName = "IsAvailable";
            this.IsAvailable.HeaderText = "IsAvailable";
            this.IsAvailable.Name = "IsAvailable";
            // 
            // CateringServices
            // 
            this.CateringServices.DataPropertyName = "CateringServices";
            this.CateringServices.HeaderText = "CateringServices";
            this.CateringServices.Name = "CateringServices";
            // 
            // HasTechnicalSupport
            // 
            this.HasTechnicalSupport.DataPropertyName = "HasTechnicalSupport";
            this.HasTechnicalSupport.HeaderText = "HasTechnicalSupport";
            this.HasTechnicalSupport.Name = "HasTechnicalSupport";
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            // 
            // isAvailableDataGridViewCheckBoxColumn
            // 
            this.isAvailableDataGridViewCheckBoxColumn.DataPropertyName = "IsAvailable";
            this.isAvailableDataGridViewCheckBoxColumn.HeaderText = "IsAvailable";
            this.isAvailableDataGridViewCheckBoxColumn.Name = "isAvailableDataGridViewCheckBoxColumn";
            // 
            // cateringServicesDataGridViewCheckBoxColumn
            // 
            this.cateringServicesDataGridViewCheckBoxColumn.DataPropertyName = "CateringServices";
            this.cateringServicesDataGridViewCheckBoxColumn.HeaderText = "CateringServices";
            this.cateringServicesDataGridViewCheckBoxColumn.Name = "cateringServicesDataGridViewCheckBoxColumn";
            // 
            // hasTechnicalSupportDataGridViewCheckBoxColumn
            // 
            this.hasTechnicalSupportDataGridViewCheckBoxColumn.DataPropertyName = "HasTechnicalSupport";
            this.hasTechnicalSupportDataGridViewCheckBoxColumn.HeaderText = "HasTechnicalSupport";
            this.hasTechnicalSupportDataGridViewCheckBoxColumn.Name = "hasTechnicalSupportDataGridViewCheckBoxColumn";
            // 
            // conferenceRoomBindingSource1
            // 
            this.conferenceRoomBindingSource1.DataSource = typeof(ResortManagement_WindowsF.CLASS.ConferenceRoom);
            // 
            // conferenceRoomBindingSource
            // 
            this.conferenceRoomBindingSource.DataSource = typeof(ResortManagement_WindowsF.CLASS.ConferenceRoom);
            // 
            // trinaryHallBindingSource
            // 
            this.trinaryHallBindingSource.DataSource = typeof(ResortManagement_WindowsF.CLASS.TrinaryHall);
            // 
            // cottageReefBindingSource
            // 
            this.cottageReefBindingSource.DataSource = typeof(ResortManagement_WindowsF.CLASS.CottageReef);
            // 
            // ConferenceRoomfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 515);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
          //  this.Name = "ConferenceRoomfrm";
            this.Text = "ConferenceRoom";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conferenceRoomBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conferenceRoomBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trinaryHallBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cottageReefBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCapacity;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearchID;
        private System.Windows.Forms.Button btnPut;
        private System.Windows.Forms.TextBox txtSearchID;
        private System.Windows.Forms.CheckBox chkIsAvailable;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnPost;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.BindingSource cottageReefBindingSource;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource trinaryHallBindingSource;
        private System.Windows.Forms.BindingSource conferenceRoomBindingSource;
        private System.Windows.Forms.CheckBox chkHasTechnicalSupport;
        private System.Windows.Forms.CheckBox chkCateringServices;
        private System.Windows.Forms.BindingSource conferenceRoomBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Capacity;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IsAvailable;
        private System.Windows.Forms.DataGridViewCheckBoxColumn CateringServices;
        private System.Windows.Forms.DataGridViewCheckBoxColumn HasTechnicalSupport;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isAvailableDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cateringServicesDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn hasTechnicalSupportDataGridViewCheckBoxColumn;
    }
}