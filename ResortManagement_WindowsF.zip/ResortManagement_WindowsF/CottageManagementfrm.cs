﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Net.Http;
using Newtonsoft.Json;
using ResortManagement_WindowsF.CLASS;
using Microsoft.VisualBasic;



namespace ResortManagement_WindowsF
{
    public partial class CottageManagementfrm : Form
    {
        private static readonly HttpClient client = new HttpClient();
        public CottageManagementfrm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void CottageManagementfrm_Load(object sender, EventArgs e)
        {

        }

        private void cottageManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cottageReefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new CottageReeffrm();
            form.Show();
        }

        private void trinaryHallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new TrinaryHallfrm();
            form.Show();
        }

        private void conferenceRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ConferenceRoomfrm();
            form.Show();
        }

        private void comboMealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new ComboMealfrm();
            form.Show();
        }

        private void pbxHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new Form1();
            form.Show();
        }


        private async void btnPut_Click(object sender, EventArgs e)
        {
            string idInput = txtID.Text; // This TextBox should allow ID editing
            string searchIdInput = txtSearchID.Text; // This is the ID to search and check existence

            // Check if the ID input is empty
            if (string.IsNullOrWhiteSpace(idInput))
            {
                MessageBox.Show("Please enter a Cottage ID to update.");
                return;
            }

            // Try parsing the ID from the TextBox
            if (!int.TryParse(idInput, out int cottageId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Check if the Cottage ID exists before trying to update it
            if (!await CottageIdExists(cottageId))
            {
                MessageBox.Show($"Cottage with ID {cottageId} does not exist.");
                return;
            }

            // Gather data from inputs
            Cottage updatedCottage = new Cottage
            {
                Id = cottageId, // Use the ID entered in txtID
                Name = txtCottageName.Text,
                IsAvailable = chkIsAvailable.Checked,
                Capacity = int.Parse(txtCottageCapacity.Text),
                CheckIn = dtpCheckIn.Value,
                CheckOut = dtpCheckOut.Value
            };

            // API URL
            string apiUrl = $"http://localhost:5083/api/Cottage/{cottageId}";

            try
            {
                // Convert the updatedCottage object to JSON
                string jsonData = JsonConvert.SerializeObject(updatedCottage);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the PUT request to the API
                HttpResponseMessage response = await client.PutAsync(apiUrl, content);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("Cottage updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private async Task<bool> CottageIdExists(int cottageId)
        {
            string apiUrl = $"http://localhost:5083/api/Cottage/{cottageId}"; // Adjust the URL as per your API
            HttpResponseMessage response = await client.GetAsync(apiUrl);

            return response.IsSuccessStatusCode; // Returns true if the cottage exists
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            string searchIdInput = txtSearchID.Text; // Replace with your textbox name for searching
            if (string.IsNullOrWhiteSpace(searchIdInput))
            {
                MessageBox.Show("Please enter a Cottage ID to delete.");
                return;
            }

            if (!int.TryParse(searchIdInput, out int cottageId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            // Confirm deletion
            var confirmResult = MessageBox.Show("Are you sure you want to delete this Cottage?",
                                                 "Confirm Delete",
                                                 MessageBoxButtons.YesNo);
            if (confirmResult != DialogResult.Yes)
            {
                return; // Exit if the user does not confirm
            }

            // API URL for deletion
            string apiUrl = $"http://localhost:5083/api/Cottage/{cottageId}";

            try
            {
                HttpResponseMessage response = await client.DeleteAsync(apiUrl);

                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    MessageBox.Show("Cottage not found.");
                    return;
                }

                response.EnsureSuccessStatusCode();

                MessageBox.Show("Cottage deleted successfully!");

                // Optionally, clear the fields after deletion
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
        private void ClearFields()
        {
            txtID.Text = string.Empty;
            txtSearchID.Text = string.Empty;
            txtCottageName.Text = string.Empty;
            txtCottageCapacity.Text = string.Empty;
            chkIsAvailable.Checked = false;
            dtpCheckIn.Value = DateTime.Now; // or set to a default date
            dtpCheckOut.Value = DateTime.Now; // or set to a default date
        }

        private async void btnPost_Click(object sender, EventArgs e)
        {
            // Get data from input fields
            string idInput = txtID.Text; // Cottage ID input
            string name = txtCottageName.Text; // Cottage Name input
            string capacityInput = txtCottageCapacity.Text; // Capacity input
            DateTime checkIn = dtpCheckIn.Value; // Check-In date
            DateTime checkOut = dtpCheckOut.Value; // Check-Out date
            bool isAvailable = chkIsAvailable.Checked; // Availability checkbox

            // Validate the ID
            if (string.IsNullOrWhiteSpace(idInput) || !int.TryParse(idInput, out int cottageId))
            {
                MessageBox.Show("Invalid or missing Cottage ID. Please enter a valid number.");
                return;
            }

            // Check if the cottage ID already exists
            if (await CottageExists(cottageId))
            {
                MessageBox.Show("A cottage with the same ID already exists. Please enter a unique ID.");
                return;
            }

            // Validate other inputs
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Cottage Name is required.");
                return;
            }

            if (!int.TryParse(capacityInput, out int capacity) || capacity <= 0)
            {
                MessageBox.Show("Invalid Capacity. Please enter a positive number.");
                return;
            }

            // Create a new Cottage object
            Cottage newCottage = new Cottage
            {
                Id = cottageId, // Use the provided ID
                Name = name,
                IsAvailable = isAvailable,
                Capacity = capacity,
                CheckIn = checkIn,
                CheckOut = checkOut
            };

            string apiUrl = "http://localhost:5083/api/Cottage"; // URL to your API

            try
            {
                // Serialize the Cottage object to JSON
                string jsonData = JsonConvert.SerializeObject(newCottage);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Make the POST request to the API
                HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                // Check if the response is successful
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Cottage added successfully!");
                    ClearFields(); // Optional: Clear fields after adding
                }
                else
                {
                    MessageBox.Show("Error adding Cottage: " + response.ReasonPhrase);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
        private async Task<bool> CottageExists(int id)
        {
            HttpResponseMessage response = await client.GetAsync($"http://localhost:5083/api/Cottage/{id}");
            return response.IsSuccessStatusCode; // Returns true if the cottage exists
        }


        private async void button1_Click_1(object sender, EventArgs e)
        {
            string searchIdInput = txtSearchID.Text;

            if (string.IsNullOrWhiteSpace(searchIdInput))
            {
                MessageBox.Show("Please enter a Cottage ID to search.");
                return;
            }

            if (!int.TryParse(searchIdInput, out int cottageId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid number.");
                return;
            }

            string apiUrl = $"http://localhost:5083/api/Cottage/{cottageId}";

            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    MessageBox.Show("Cottage not found.");
                    return;
                }

                response.EnsureSuccessStatusCode();
                string jsonResponse = await response.Content.ReadAsStringAsync();
                Cottage foundCottage = JsonConvert.DeserializeObject<Cottage>(jsonResponse);

                // Fill the form fields with the retrieved data
                txtCottageName.Text = foundCottage.Name;
                txtCottageCapacity.Text = foundCottage.Capacity.ToString();
                chkIsAvailable.Checked = foundCottage.IsAvailable;

                // Update the ID TextBox to allow editing
                txtID.Text = foundCottage.Id.ToString(); // Ensure the ID is shown
                txtID.ReadOnly = false; // Ensure the ID can be edited
                txtID.Focus(); // Optional: set focus to the ID TextBox
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

   

        private async void button9_Click(object sender, EventArgs e)
        {

            string apiUrl = "http://localhost:5083/api/Cottage";


            try
            {
                // Send a GET request to the API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseData = await response.Content.ReadAsStringAsync();

                // Deserialize the JSON response to a list of ComboMeal objects
                List<Cottage> comboMeals = JsonConvert.DeserializeObject<List<Cottage>>(responseData);

                // Bind the data to the DataGridView
                dataGridView1.DataSource = comboMeals;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Request error: {ex.Message}");
            }
        }
    }
}
