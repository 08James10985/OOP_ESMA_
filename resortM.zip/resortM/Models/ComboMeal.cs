﻿namespace ResortManagementSystem_2.Model
{

    public class ComboMeal
    {
        public int Id { get; set; }
        public string MealName { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
    }
}
