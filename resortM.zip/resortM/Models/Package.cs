﻿namespace ResortManagementSystem_2.Model
{
    public class Packages
    {
        public int Id { get; set; }
        public string PackageName { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
    }
}
